/* let a = [1, 2, 4, 5, 6, 7]; concept we use 2d 
find the greatest element in an array*/
let a = [1, 2, 3, 4, 5, 6, 7,15];
let greatest = a[0];
for (let i = 1; i < a.length; i++) {
    if (a[i] > greatest) {
        greatest = a[i];
    }
}
document.getElementById("output").innerHTML = "The greatest element is: " + greatest;

/* let a = [1, 2, 4, 5, 6, 7]; concept we use 2d 
find the greatest element in an array*/
let demo = document.querySelector("#demo");
let b = [
  [1, 2, 3, 4, 5, 6, 7]
];

let max = -Infinity;

for (let row = 0; row < b.length; row++) {
  for (let col = 0; col < b[row].length; col++) {
    if (b[row][col] > max) {
      max = b[row][col];
    }
  }
}

demo.innerHTML = "The greatest element is: " + max;
console.log("Greatest element:", max);



