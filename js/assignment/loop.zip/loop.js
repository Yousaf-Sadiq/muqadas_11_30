let div = document.querySelector(".output");
// Sum all the array elements by using a loop
const arr = [4, 25, 12,35];
value = 0;
for (let i = 0; i <4; i++) {
  value += arr[i];
  console.log(arr[i])
}
div.innerHTML=value;

// 2. Make a reverse of the array by using a loop.
let div1 = document.querySelector(".output1");
const array = [4, 25, 12,35];
array.reverse()
console.log(array)
div1.innerHTML=array;

// Print numbers from 1 to 100, but for multiples of 3 print "Fizz", for multiples of 5, print
// "Buzz" and for numbers that are multiples of both 3 and 5 print "FizzBuzz".
let div2 = document.querySelector(".output2");
for (let i = 1; i <= 100; i++) {
  let result = "";
  if (i % 3 === 0 && i % 5 === 0) {
    result = "FizzBuzz";
  } else if (i % 3 === 0) {
    result = "Fizz";
  } else if (i % 5 === 0) {
    result = "Buzz";
  }
  div2.innerHTML=result;
}

/* Write a function to calculate the factorial of a given number.
i = int(input("Enter a number: "))
fac = 1;
while (i>0);
fac=fac*i;
i=i-1;*/
let div3 = document.querySelector(".output3");
i = 5
fac = 1
while (i > 0)
    fac = fac * i
    i = i - 1
print(fac)
div3.innerHTML=fac;

// Write a function that determines whether a given number is prime or not.
let div4 = document.querySelector(".output4");
n=7
count=0
i=1
while(i<=n)
  if(n%i==0){
    count=cont+1
  }
  i=i+1
  if (count==2) {
    print = "prime";
  } else if (count==3) {
    print = "not prime";
  }
  div4.innerHTML=print;


  