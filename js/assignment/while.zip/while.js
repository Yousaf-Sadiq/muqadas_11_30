// Sum all the array elements by using a loop
let div = document.querySelector(".output");
const arr = [4, 25, 12, 35, 21, 321];
let value = 0;
let i = 0;
while (i < arr.length) {
  value += arr[i];
  console.log(arr[i]);
  i++;
}
div.innerHTML = `The Value is : ${value}<hr style="height:4px; background-color:black;">`; 



// 2. Make a reverse of the array by using a loop.
let div1 = document.querySelector(".output1");
const array = [4, 25, 12, 35, 676, 7654];
let revArray = [];
let arrRange = (array.length - 1);
let index = arrRange;
while (index >= 0) {
  revArray.push(array[index]);
  index--;
}
div1.innerHTML =`The RevArray is : ${ revArray} <hr style="height:4px; background-color:black;">`; 

// Print numbers from 1 to 100, but for multiples of 3 print "Fizz", for multiples of 5, print
// "Buzz" and for numbers that are multiples of both 3 and 5 print "FizzBuzz".
let div2 = document.querySelector(".output2");
let result = "";
let a = 1;
while (a <= 100)  {
    if (a % 3 === 0 && a % 5 === 0) {
      result += `${a} that's why we called FizzBuzz <br>`;
    } else if (a % 3 === 0) {
      result += `${a} that's why we called Fizz <br>`;
    } else if (a % 5 === 0) {
      result += `${a} that's why we called Buzz <br>`;
    } 
    a++; 
  }
  div2.innerHTML = `${result} <hr style="height:4px; background-color:black;">`;


 // Write a function to calculate the factorial of a given number.
 let div3 = document.querySelector(".output3");

 function findFact(n) {
   let multi = 1;
   for (let start = n; start >= 1; start--) {
     multi *= start;
   }
   return multi;
 }
 
 div3.innerHTML = `Factorial is: ${findFact(5)} <hr style="height:4px; background-color:black;">`;


// Write a function that determines whether a given number is prime or not.
let div4 = document.querySelector(".output4");
let count = 0;
let n = 7; 
let output = "";

for (let i = 1; i <= n; i++) {
  if (n % i == 0) {
    count++;
  }
}

if (count == 2) {
  output = "prime";
} else {
  output = "not prime";
}

div4.innerHTML = `The number ${n} is ${output} <hr style="height:5px; background-color:black;">`;

