
<?php 


define("USER","user_table");
define("ADDRESS","user_address");

?>
