<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasty Bites</title>
    <link rel="stylesheet" href="./bootstrap.css">
    <style>
        .background-image {
            height: 100vh;
            background-image: url('./purple-sky-palm-trees-lake.jpg');
            background-size: cover;
            background-position: center;
            position: relative;
        }
        .navbar {
            position: absolute;
            width: 100%;
            top: 0;
            background-color: #660066; /* deep plum color */
        }
        .navbar-nav .nav-link {
            color: #fff; /* white color */
            font-size: 18px;
            font-weight: bold;
        }
        .navbar-brand {
            color: #fff; /* white color */
            font-size: 24px;
            font-weight: bold;
        }
        .navbar-text {
            color: #fff; /* white color */
        }
        .dropdown-menu {
            background-color: #660066; /* deep plum color */
        }
        .dropdown-item {
            color: #fff; /* white color */
        }
        .nav-pills .nav-link {
            color: #fff; /* white color */
        }
        .btn-outline-success {
            color: #fff; /* white color */
            border-color: #fff; /* white color */
        }
        

    </style>
</head>
<body>
    <div class="background-image">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Tasty Bites</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">Home</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Menu</a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="#">Breakfast</a></li>
                            <li><a class="dropdown-item" href="#">Lunch</a></li>
                            <li><a class="dropdown-item" href="#">Dinner</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#">Desserts</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
                <form class="d-flex" role="search">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
        </nav>
    </div>
    
    <script src="./bootstrap.bundle.js"></script>
</body>
</html>


