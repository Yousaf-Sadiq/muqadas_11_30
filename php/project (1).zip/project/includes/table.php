
<?php 


define("USER","user_table");

?>
