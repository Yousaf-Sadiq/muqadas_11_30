//Check from the given integer, whether it is positive or negative//
let i = 5;
let result;
if (i > 9)
    {result = "positive";
  console.log("The number is positive");} 
  else if (i < 9) 
    {result = "negative";
  console.log("The number is negative");} 
let h1 = document.getElementById("style");
h1.innerHTML = "THE NUMBER IS : " + result;

//Check whether a given number is even or odd. (mod sign % )//
let num = 4;
let resultType;
if (num % 2===0) 
    {resultType = "even";
  console.log("The number is even");} 
  else
  { resultType = "odd";
  console.log("The number is odd");}
let h2 = document.getElementById("style1");
h2.innerHTML = "THE NUMBER IS : " + resultType;

//Check whether a given positive number is a multiple of 3.//
let num2 = 9;
let resultMultiple;
if (num2 % 3 === 0) 
    { resultMultiple = "multiple of 3";
  console.log("The number is a multiple of 3")}
   else  
   {resultMultiple = "not a multiple of 3";
  console.log("The number is not a multiple of 3");}
let h3 = document.getElementById("style2");
h3.innerHTML = "THE NUMBER IS : " + resultMultiple;












