let q = ["qwer", 12, 432, true, 432, 132, 6765, 8769, 123, 321, 1321, 432, "dsajdsamskl"]
let L = q.length;

let range = L - 1; // 8

console.log(q[range]);
//  start  condition/end  increament/decreament 
for (let i = 0; i <= range; i++) {


   document.write(q[i]+"<br>");

}

// index array
// associative array / object
// multi dimension arrays
// q.splice(1,2,"abc","qwer");

let r = q.slice(3, 9);
console.log(r);

const array1 = [1, 4, 9, 16];

// Pass a function to map
const map1 = array1.map((ele) => {

    let a = ele * 8

    return a;
});
//  [7,10,15,22]


// Find the last element of an array without giving a hard-coded index.

// 2. Check whether the first or the last index 
// of an array has a specified value, let's say 5.

// 3. Make an array to store the names of students 
// and check whether that array has your own
// name or not and also return the index of that value.

// include function in array 
// indexof lastIndexOf  join 


// 4. Add the array element at the specified index.

// =====================research work ==============================
// loops
/**
 * while loops 
 * for loop
 * for in loop
 * for of loop 
 * 
 * do while loop
 * 
 * foreach 
 */

console.log(map1);


const array2 = [1, 4, 9, 16];

let arr = array2.filter(function (ele) {
    return ele >= 9
})
console.log(arr)