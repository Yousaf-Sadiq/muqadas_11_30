//   variables 2 

//  let var const  *

//  keyword
//  assignment operator
const a = 5;

let b = null; // declaration

// b = "2"; //initialization
// "" '' 
// data types
// 1. number
// 2. string
// 3. boolean 0 1
// 4. null
// 5. undefined
// 6. object
// 7. function 
// 8. arrays 

console.log(b)
