// 1. Find the area of a rectangle where the length is 5 and the width is 8.
let h1 = document.getElementById("style");
function areaOfRectangle(w, q) {
    let length = q;
    let width = w;
    let area = length * width;
    return area;
}
let z = areaOfRectangle(8, 5)
let a = areaOfRectangle(18, 3)
h1.innerHTML = z;

//2. Find the area of a triangle where the base is 4 and the height is 3.
let h2 = document.getElementById("style1");
function areaOftriangle(a, b) {
  let base = a;
  let height = b;
  let area = base * height/2;
  return area;
}
let c = areaOftriangle(4, 3)
h2.innerHTML = c;

//3. Find the area of a circle where the radius is 3.
let h3 = document.getElementById("style2");
function areaOfCircle(r) {
  let area = Math.PI * r * r;
  return area;
}
let d = areaOfCircle(3)
h3.innerHTML = d;

// 4. Convert temperatures from Celsius to Fahrenheit and Fahrenheit to Celsius.
// Celsius to Fahrenheit
let h4 = document.getElementById("style3");
function celsiusToFahrenheit(c) {
  let f = (c * 9/5) + 32;
  return f;
}
let e = celsiusToFahrenheit(30)
h4.innerHTML = e;

// Fahrenheit to Celsius
let h5 = document.getElementById("style4");
function fahrenheitToCelsius(f) {
  let c = (f - 32) * 5/9;
  return c;
}
let f = fahrenheitToCelsius(60)
h5.innerHTML = f;

//5. Check from the given integer, whether it is positive or negative.
let h6 = document.getElementById("style5");
function checkNumber(n) {
  if (n > 0) {
    return "Positive";
  } else if (n < 0) {
    return "Negative";
  } }
let g = checkNumber(4)
h6.innerHTML = g;

//6.  Check whether a given number is even or odd. (mod sign % )
let h7 = document.getElementById("style6");
function checkEvenOdd(num) {
  if (num % 2 === 0) {
    return "Even";
  } else {
    return "Odd";
  }
}
let h = checkEvenOdd(24)
h7.innerHTML = h;

//7.  Check whether a given positive number is a multiple of 3.
let h8 = document.getElementById("style7");
function checkMultipleOfThree(num) {
  if ( num % 3 === 0) {
    return "Multiple of 3";
  } else {
    return "Not a multiple of 3";
  }
}
let i = checkMultipleOfThree(9)
h8.innerHTML = i;





