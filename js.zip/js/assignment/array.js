//push//
let toys = ['car', 'train', 'football'];

function addElement(arr, ele) {

    arr.push(ele);

    return arr;
    // console.log(toys);
}

let h1 = document.getElementById("lead");
h1.innerHTML = "Toys: " + addElement(toys, "abc");

//unshift//
let numbers = [30, 40];
numbers.unshift(10, 20);
console.log(numbers);
let h2 = document.getElementById("lead1");
h2.innerHTML = "Numbers: " + numbers;

//pop//
let colors = ['red', 'green', 'blue'];
colors.pop();
console.log(colors);
let h3 = document.getElementById("lead2");
h3.innerHTML = "COLORS: " + colors;

//shift//
let days = ['Monday', 'Tuesday', 'Wednesday'];
days.shift();
console.log(days);
let h4 = document.getElementById("lead3");
h4.innerHTML = "DAYS : " + days;
