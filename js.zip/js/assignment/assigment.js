//Find the area of a rectangle where the length is 5 and the width is 8//
let length = 5;
let width = 8;
let area = length*width ;
let h1 = document.getElementById("note")
h1.innerHTML = "AREA OF RECTANGLE : " + area; 

//Find the area of a triangle where the base is 4 and the height is 3.//
let base = 4;
let Height = 3;
let AREA = (base*Height)/2;
let h2 = document.getElementById("note1")
h2.innerHTML = "AREA OF TRIANGLE : " + AREA;

//Find the area of a circle where the radius is 3//
let radius = 3;
let A = Math.PI *radius**2;
let h3 = document.getElementById("note2")
h3.innerHTML = "AREA OF CIRCLE : " + A;

/*Convert temperatures from Celsius to Fahrenheit and Fahrenheit to Celsius.
Celsius to Fahrenheit*/
let celsius = 25;
let fahrenheit = (celsius * 9/5) + 32;
let h4 = document.getElementById("note3");
h4.innerHTML = "TEMPERATURE IN FAHRENHEIT : " + fahrenheit;

//Fahrenheit to Celsius//

let Fahrenheit = 80;
let Celsius = (Fahrenheit - 32) * 5/9;
let h5 = document.getElementById("note4");
h5.innerHTML = "TEMPERATURE IN CELSIUS : " + Celsius;














